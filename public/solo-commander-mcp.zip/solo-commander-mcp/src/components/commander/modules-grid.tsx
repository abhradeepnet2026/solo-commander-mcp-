"use client";

import { MODULES, ACCENT_CLASSES } from "./data";
import { SectionHeading } from "./section-heading";

export function ModulesGrid() {
  return (
    <section id="modules" className="relative scroll-mt-20 py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <SectionHeading
          eyebrow="// 15 modules"
          title="Everything an AI agent needs to drive your machine"
          description="Each module exposes a set of MCP tools. Your AI client calls them the same way it calls any other tool — except these ones reach into your real filesystem, terminal, git history, and processes."
        />

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {MODULES.map((m) => {
            const a = ACCENT_CLASSES[m.accent];
            const Icon = m.icon;
            return (
              <div
                key={m.id}
                className={`group relative flex flex-col rounded-xl border border-border/70 bg-card/50 p-5 ring-1 ring-transparent transition-all duration-300 hover:-translate-y-0.5 hover:bg-card/80 ${a.ring}`}
              >
                {/* header */}
                <div className="flex items-start justify-between gap-3">
                  <div
                    className={`flex h-11 w-11 items-center justify-center rounded-lg border ${a.border} ${a.bg}`}
                  >
                    <Icon className={`h-5 w-5 ${a.text}`} />
                  </div>
                  <span className="font-mono text-xs text-muted-foreground">
                    {String(m.id).padStart(2, "0")}
                  </span>
                </div>

                <h3 className="mt-4 font-semibold tracking-tight">{m.name}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{m.tagline}</p>

                {/* functions */}
                <ul className="mt-4 grid gap-1.5">
                  {m.functions.map((f) => (
                    <li
                      key={f}
                      className="flex items-center gap-2 font-mono text-[12px] text-foreground/70"
                    >
                      <span className={`h-1 w-1 rounded-full ${a.dot}`} />
                      {f}
                    </li>
                  ))}
                </ul>

                <div className="mt-4 border-t border-border/50 pt-3">
                  <code className={`font-mono text-[11px] ${a.text}`}>
                    mcp.commander.{m.slug}
                  </code>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
