# Solo Desktop Commander MCP

A completely free, open-source **Desktop Commander MCP** for solo developers and vibe coders.
Give any MCP-compatible AI agent real filesystem, terminal, git, and process control over your
own machine — inspect, diagnose, repair, and verify, all from chat. No accounts. No cloud.
No telemetry. No login.

This package contains the **web application** that showcases the project: a polished, interactive
landing page plus a **working MCP-style server** that genuinely inspects a live project.

---

## What's inside

```
solo-commander-mcp/
├── src/
│   ├── app/
│   │   ├── api/commander/route.ts     # MCP-style tool endpoint (filesystem, git, exec, processes)
│   │   ├── page.tsx                   # Single-page showcase (the only user route)
│   │   ├── layout.tsx
│   │   └── globals.css                # Terminal-dark theme (emerald + amber, no indigo/blue)
│   ├── components/
│   │   ├── commander/                 # All landing-page sections
│   │   │   ├── header.tsx  hero.tsx  stats-bar.tsx  modules-grid.tsx
│   │   │   ├── architecture.tsx  workflow.tsx  terminal-demo.tsx
│   │   │   ├── installation.tsx  config-security.tsx  comparison.tsx
│   │   │   ├── footer.tsx  section-heading.tsx  data.ts
│   │   │   └── data.ts
│   │   └── ui/                        # shadcn/ui component set
│   ├── lib/
│   │   ├── commander/executor.ts      # Safe tool dispatcher (path-confined, allowlisted)
│   │   ├── db.ts  utils.ts
│   └── hooks/
├── prisma/schema.prisma
├── public/
├── package.json  bun.lock  tsconfig.json  next.config.ts
├── tailwind.config.ts  postcss.config.mjs  components.json  eslint.config.mjs
├── Caddyfile
└── README.md  (this file)
```

## The interactive MCP server

The endpoint at `POST /api/commander` is a **real, working** MCP-style tool server. It exposes:

| Tool             | What it does                                              |
|------------------|-----------------------------------------------------------|
| `project_info`   | Detects framework, language, package manager, scripts     |
| `list_files`     | Prints a tree of a directory (path-confined)              |
| `read_file`      | Reads a file (confined to project root, size-capped)      |
| `git_status`     | `git status --porcelain`                                  |
| `git_log`        | Recent commit history                                     |
| `git_branch`     | Current branch + all branches                             |
| `run_command`    | Runs a **safe allowlisted** shell command                 |
| `list_processes` | Top processes by memory                                   |

### Security model (built-in, on by default)

- **Path confinement** — filesystem tools cannot escape the project root.
- **Command allowlist** — `run_command` only executes known-safe commands
  (`node --version`, `bun --version`, `git --version`, …). Everything else
  (e.g. `rm -rf /`) is refused with a clear message.
- **Structured errors** — every failure returns `{ ok: false, output }`, never a 500.
- Every call is **logged & timestamped** in the on-screen activity log.

---

## Run it locally

Requires **Node 18+** and **Bun** (recommended) or npm/pnpm.

```bash
# 1. install dependencies
bun install        # or: npm install / pnpm install

# 2. configure the database url
cp .env.example .env

# 3. (optional) push the prisma schema
bun run db:push

# 4. start the dev server
bun run dev        # or: npm run dev
```

Then open **http://localhost:3000**.

> The homepage is the only user-facing route (`src/app/page.tsx`).
> The MCP tool endpoint lives at `/api/commander`.

---

## Tech stack

- **Next.js 16** (App Router) + **TypeScript 5**
- **Tailwind CSS 4** + **shadcn/ui** (New York)
- **Prisma ORM** (SQLite)
- **lucide-react** icons, **framer-motion**, **sonner** toasts
- Forced dark "terminal" theme with emerald/amber accents

## Design principles

Free · Open Source · Offline First · Cross Platform · No Account · No Cloud ·
No Telemetry · No Vendor Lock-in.

## License

MIT — built for solo developers and vibe coders.
